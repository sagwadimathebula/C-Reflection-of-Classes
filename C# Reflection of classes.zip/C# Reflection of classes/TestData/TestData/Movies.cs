﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestData
{
    public class Movies
    {
        public int Fast_And_Furious(int movie)
        {
            int result = movie;
            return result;
        }
        public int EndGame(int movie)
        {
            int result = movie;
            return result;
        }
    }
}
