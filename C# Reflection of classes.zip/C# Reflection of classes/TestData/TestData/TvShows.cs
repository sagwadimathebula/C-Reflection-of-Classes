﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestData
{
    public class TvShows
    {
        public int Keeping_Up_With_The_Khardashians(int tvshow)
        {
            int result = tvshow;
            return result;
        }
        public int Oprah(int tvshow)
        {
            int result = tvshow;
            return result;
        }
    }
}

