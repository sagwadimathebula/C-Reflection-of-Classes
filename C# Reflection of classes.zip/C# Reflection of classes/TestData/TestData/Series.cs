﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestData
{
     public class Series
    {
        public int Atlanta(int Series)
        {
            int result = Series;
            return result;
        }

        public int Power(int Series)
        {
            int result = Series;
            return result;
        }
        public int BlackPanther(int Series)
        {
            int result = Series;
            return result;
        }
        public int Flash(int Series)
        {
            int result = Series;
            return result;
        }
        public int supergirl(int Series)
        {
            int result = Series;
            return result;
        }

        public int Isibaya(int Series)
        {
            int result = Series;
            return result;
        }

        public int The_Queen(int Series)
        {
            int result = Series;
            return result;
        }
        public int How_To_Love(int Series)
        {
            int result = Series;
            return result;
        }
        public int Insecure(int Series)
        {
            int result = Series;
            return result;
        }
        public int Generations(int Series)
        {
            int result = Series;
            return result;
        }
    }
}

