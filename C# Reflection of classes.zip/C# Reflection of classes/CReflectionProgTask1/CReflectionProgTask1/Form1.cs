﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CReflectionProgTask1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            GridClasses.Columns.Add("a", "Class");
            GridClasses.Columns.Add("b", "Number Methods");
            GridLines.Columns.Add("a", "Class");
            GridLines.Columns.Add("b", "Method");
            GridLines.Columns.Add("c", "Byte Size");
            GridLinesUser.Columns.Add("a", "Class");
            GridLinesUser.Columns.Add("b", "Method");
            GridLinesUser.Columns.Add("c", "Byte Size");
           GridExtReff.Columns.Add("a", "Name");//to do doublech what is meant by external refernce...
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public void Info()
        {

            using (OpenFileDialog opf = new OpenFileDialog())
            {
                opf.ShowDialog();
                //MessageBox.Show(opf.FileName);
                Assembly a = Assembly.LoadFile(opf.FileName);
                int countMethods = 0, countClass = 0;
                GridExtReff.Rows.Clear();
                GridClasses.Rows.Clear();
                GridLines.Rows.Clear();
                GridLinesUser.Rows.Clear();
                List<String> classList = new List<String>();
                List<String> methodList = new List<String>();
                Type[] Types = a.GetTypes();
                List<AssemblyName> ExRef = a.GetReferencedAssemblies().ToList();
                //START External Reference
                foreach (var exRef in ExRef)
                {
                    GridExtReff.Rows.Add(exRef.FullName);
                }

                GridExtReff.Sort(GridExtReff.Columns["a"], ListSortDirection.Ascending);
                GridExtReff.AutoResizeColumns();
                GridExtReff.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                //END External Reference
                //loading bar
                int loadbarClassCount = 0;
                foreach (Type classesCount in Types)
                {
                    loadbarClassCount++;
                }
                
             
                //

                foreach (Type classes in Types)
                {
                   
                    txtname.Text = classes.Assembly.ToString();

                    if (classes.IsAbstract)
                    {
                        Console.WriteLine("Abstract Class : " + classes.Name);
                    }
                    else if (classes.IsPublic)
                    {
                        Console.WriteLine("Public Class : " + classes.Name);
                        classList.Add(classes.Name);
                    }
                    else if (classes.IsSealed)
                    {
                        Console.WriteLine("Sealed Class : " + classes.Name);
                    }

                    MethodInfo[] methods = classes.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.Public);
                    foreach (MethodInfo method in methods)
                    {
                        try
                        {
                            MethodBody mb = method.GetMethodBody();//for byte size
                            Console.WriteLine("Public Method : " + method.Name);
                            countMethods++;

                            GridLines.Rows.Add(classes.Name, method.Name, mb.GetILAsByteArray().Length);
                            GridLinesUser.Rows.Add(classes.Name, method.Name, mb.GetILAsByteArray().Length);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("MethofInfo Error \n" + ex);
                        }

                    }

                    GridLines.Sort(GridLines.Columns["c"], ListSortDirection.Descending);
                    GridLines.AutoResizeColumns();
                    GridLines.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

                    GridLinesUser.Sort(GridLinesUser.Columns["c"], ListSortDirection.Descending);
                    GridLinesUser.AutoResizeColumns();
                    GridLinesUser.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

                    Console.WriteLine("Num Of methods:  " + countMethods);
                    methodList.Add(countMethods.ToString());
                    countMethods = 0;
                    countClass++;

                }
                int numClasses = classList.Count;
                int numMethods = methodList.Count;
                string[,] classes2d = new string[numClasses, numMethods];

                for (int i = 0; i < classList.Count; i++)
                {

                    GridClasses.Rows.Add(classList[i], Int64.Parse(methodList[i]));

                }

                GridClasses.Sort(GridClasses.Columns["b"], ListSortDirection.Descending);
                GridClasses.AutoResizeColumns();
                GridClasses.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            }


        }

        public void InfoLinesUser()
        {
            try
            {

                int gvLinesUserRowCount = GridLinesUser.RowCount;

                btnsearch.Visible = true;
              

                for (int i = 0; i <= gvLinesUserRowCount; i++)
                {

                  while (Int32.Parse(GridLinesUser.Rows[i].Cells[2].Value.ToString()) <= Int32.Parse(txtlines.Text))
                    {

                        GridLinesUser.Rows.Remove(GridLinesUser.Rows[i]);
                        gvLinesUserRowCount--;
                        GridLinesUser.Refresh();
                        Console.WriteLine(i + " " + gvLinesUserRowCount + " " + Int32.Parse(GridLinesUser.Rows[i].Cells[2].Value.ToString()));
                       // btnsearch.PerformStep();
                    }
                   
                }


                GridLinesUser.Refresh();
                GridLinesUser.AutoResizeColumns();
                GridLinesUser.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                GridLinesUser.Sort(GridLinesUser.Columns["c"], ListSortDirection.Descending);
            }
            catch (Exception ex)
            {

                Console.WriteLine("InfoLinesUser Error on Remove \n" + ex);
            }
        }


       
        private void Bgw1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void Bgw1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

        }

        private void Bgw1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                Info();
            }
            catch (Exception ex)
            {
                MessageBox.Show("NOT A SUPPORTED FILE \n btnFile_Click \n" + ex.ToString());
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {

            try
            {

                InfoLinesUser();

            }
            catch (Exception ex)
            {
                MessageBox.Show("SELECT ASSEMBLY FILE");
                Console.WriteLine("btnLinesUser_Click \n" + ex);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GridClasses_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

