﻿namespace CReflectionProgTask1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GridClasses = new System.Windows.Forms.DataGridView();
            this.GridLinesUser = new System.Windows.Forms.DataGridView();
            this.GridExtReff = new System.Windows.Forms.DataGridView();
            this.GridLines = new System.Windows.Forms.DataGridView();
            this.btnLoad = new System.Windows.Forms.Button();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtlines = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.GridClasses)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridLinesUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridExtReff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridLines)).BeginInit();
            this.SuspendLayout();
            // 
            // GridClasses
            // 
            this.GridClasses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridClasses.Location = new System.Drawing.Point(13, 198);
            this.GridClasses.Name = "GridClasses";
            this.GridClasses.Size = new System.Drawing.Size(259, 150);
            this.GridClasses.TabIndex = 0;
            this.GridClasses.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridClasses_CellContentClick);
            // 
            // GridLinesUser
            // 
            this.GridLinesUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridLinesUser.Location = new System.Drawing.Point(47, 466);
            this.GridLinesUser.Name = "GridLinesUser";
            this.GridLinesUser.Size = new System.Drawing.Size(592, 150);
            this.GridLinesUser.TabIndex = 1;
            // 
            // GridExtReff
            // 
            this.GridExtReff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridExtReff.Location = new System.Drawing.Point(699, 198);
            this.GridExtReff.Name = "GridExtReff";
            this.GridExtReff.Size = new System.Drawing.Size(308, 150);
            this.GridExtReff.TabIndex = 2;
            // 
            // GridLines
            // 
            this.GridLines.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridLines.Location = new System.Drawing.Point(335, 198);
            this.GridLines.Name = "GridLines";
            this.GridLines.Size = new System.Drawing.Size(293, 150);
            this.GridLines.TabIndex = 3;
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(37, 91);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(180, 27);
            this.btnLoad.TabIndex = 4;
            this.btnLoad.Text = "Select a File";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(285, 95);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(654, 20);
            this.txtname.TabIndex = 5;
            // 
            // txtlines
            // 
            this.txtlines.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlines.Location = new System.Drawing.Point(423, 400);
            this.txtlines.Name = "txtlines";
            this.txtlines.Size = new System.Drawing.Size(83, 31);
            this.txtlines.TabIndex = 6;
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(526, 400);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(113, 31);
            this.btnsearch.TabIndex = 7;
            this.btnsearch.Text = "Filter";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 411);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Enter the minimum number of lines for a method";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(123, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Clases";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(471, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Methods";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(785, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "External References";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(330, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(288, 29);
            this.label5.TabIndex = 12;
            this.label5.Text = "C# Refflection Application";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(1110, 646);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtlines);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.GridLines);
            this.Controls.Add(this.GridExtReff);
            this.Controls.Add(this.GridLinesUser);
            this.Controls.Add(this.GridClasses);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GridClasses)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridLinesUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridExtReff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridLines)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView GridClasses;
        private System.Windows.Forms.DataGridView GridLinesUser;
        private System.Windows.Forms.DataGridView GridExtReff;
        private System.Windows.Forms.DataGridView GridLines;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtlines;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

